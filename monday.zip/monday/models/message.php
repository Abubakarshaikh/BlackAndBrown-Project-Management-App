<?php
class Message{
    private $table = 'messages';
    private $conn;

    public $userId;
    public $projectId;
    public $senderId;
    public $recieverId;
    public $projectName;
    public $message;
    public $createdAt;

    public function __construct($db){
        $this->conn = $db;
    }

    public function getAllByProjectId(){
        $query = " SELECT * FROM messages
WHERE projectId = ? ";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(1,$this->projectId);

        $stmt->execute();
        return  $stmt;
    }

    public function save(){
        $query = ' INSERT INTO messages
SET messages.projectId = ?, messages.message = ?, messages.senderId = ? ';

        $stmt = $this->conn->prepare($query);

        $this->projectId = htmlspecialchars(strip_tags($this->projectId));
        $this->message = htmlspecialchars(strip_tags($this->message));
        $this->senderId = htmlspecialchars(strip_tags($this->senderId));
        
        $stmt->bindParam(1, $this->projectId);
        $stmt->bindParam(2, $this->message);
        $stmt->bindParam(3, $this->senderId);
        
     
        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s.\n", $stmt->error);
        return false;
    }

}


