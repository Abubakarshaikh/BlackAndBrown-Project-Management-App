<?php

class Auth {
    private $table = 'auth';
    private $conn;

    public $email;
    public $password;
    public $token;


    public function __construct($db){
        $this->conn =$db;
    }

    public function  loginByEmailAndPassword(){
       
        $query = 
        "UPDATE auth
        SET auth.token = ?
        WHERE auth.email = ? AND auth.password = ? ";

        $stmt = $this->conn->prepare($query);
        
        $this->token = htmlspecialchars(strip_tags($this->token));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->password = htmlspecialchars(strip_tags($this->password));
        
        $stmt->bindParam(1,$this->token);
        $stmt->bindParam(2,$this->email);
        $stmt->bindParam(3,$this->password);
       
          
        $stmt->execute();
             
        return $stmt;
        
            
    }
    
    public function isLogin(){
         $query = 
        "SELECT users.id as id, users.departmentId, users.name, auth.email
FROM auth
LEFT JOIN users ON users.id = auth.userId
WHERE auth.token = ?
LIMIT 1;";

        $stmt = $this->conn->prepare($query);
        
        $this->token = htmlspecialchars(strip_tags($this->token));
        
         
        $stmt->bindParam(1,$this->token);
       
          
        $stmt->execute();
             
        return $stmt;
    }

}