<?php
class Project {
    private $conn;
    private $table = "projects";


    public $id;
    public $departmentId;
    public $name;
    public $descriptions;
    public $status;
    public $departmentName;
    public $percentage;
    public $deadline;
    public $createdAt;
    public $updatedAt;
    public function __construct($db){
        $this->conn  = $db;
    }
        
    public function getAll(){
        $query = "SELECT
departments.name as departmentName,
projects.id,
projects.name,
projects.descriptions,
projects.status,
projects.percentage,
projects.deadline,
projects.createdAt
FROM projects
LEFT JOIN departments on departments.id= projects.departmentId
WHERE projects.departmentId= ? ";

        $stmt= $this->conn->prepare($query);
        
        $stmt->bindParam(1, $this->id);
        
        $stmt->execute();
        return $stmt;
    }
                public function save() {
            $query = 'INSERT INTO projects 
             SET projects.departmentId = ?, projects.name = ?, projects.descriptions = ?, projects.status = ?, projects.deadline = ?';

             

            $stmt = $this->conn->prepare($query);
  
            $this->departmentId = htmlspecialchars(strip_tags($this->departmentId));
            $this->name = htmlspecialchars(strip_tags($this->name));
            $this->descriptions = htmlspecialchars(strip_tags($this->descriptions));
            $this->status = htmlspecialchars(strip_tags($this->status));
            $this->deadline = htmlspecialchars(strip_tags($this->deadline));
           
  
            $stmt->bindParam(1, $this->departmentId);
            $stmt->bindParam(2, $this->name);
            $stmt->bindParam(3, $this->descriptions);
            $stmt->bindParam(4, $this->status);
            $stmt->bindParam(5, $this->deadline);
          
            
    
    
            if($stmt->execute()) {
               return true;
             }
  
              printf("Error: %s.\n", $stmt->error);
     
              return false;
            }
            
            
            
            public function update(){
                
                 $query = "
                 UPDATE projects SET projects.departmentId = ?, projects.name = ?, projects.descriptions = ?, projects.percentage = ?, projects.status = ?
                 WHERE projects.id = ? ;
                 
                 ";
                
                $stmt = $this->conn->prepare($query);
 

            $this->departmentId = htmlspecialchars(strip_tags($this->departmentId));
            $this->name = htmlspecialchars(strip_tags($this->name));
            $this->descriptions = htmlspecialchars(strip_tags($this->descriptions));
            $this->percentage = htmlspecialchars(strip_tags($this->percentage));
            $this->status = htmlspecialchars(strip_tags($this->status));
                //  $this->deadline = htmlspecialchars(strip_tags($this->deadline));
             $this->id = htmlspecialchars(strip_tags($this->id));
            
          
            $stmt->bindParam(1, $this->departmentId);
            $stmt->bindParam(2, $this->name);
            $stmt->bindParam(3, $this->descriptions);
            $stmt->bindParam(4, $this->percentage);
            $stmt->bindParam(5, $this->status);
            // $stmt->bindParam(6, $this->deadline);
            $stmt->bindParam(6, $this->id);
          
            

            if($stmt->execute()) {
            
               return true;
             }
  
              printf("Error: %s.\n", $stmt->error);
     
              return false;
            
                
            }
            
            public function getById(){

               $query = " SELECT * FROM projects WHERE id = ? ";

                      $stmt= $this->conn->prepare($query);
        $this->id = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(1, $this->id);
       
        $stmt->execute();
 
    
                
                
                          $row = $stmt->fetch(PDO::FETCH_ASSOC);

          // Set properties
          $this->id = (int)$row['id'];
          $this->departmentId = (int)$row['departmentId'];
          $this->name = $row['name'];
          $this->descriptions = $row['descriptions'];
          $this->percentage = (float)$row['percentage'];
          $this->status = $row['status'];
          $this->deadline =  strtotime($row['deadline']);
          $this->createdAt =  strtotime($row['createdAt']);
          
            }
  
     }


?>