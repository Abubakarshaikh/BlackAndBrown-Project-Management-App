<?php
class Department {
    private $conn;
    public $id;
    public $name;
    public $totalProjects;
        public $completedProjects;
    public function __construct($db){
        $this->conn = $db;
    }

    public function getAll(){
        $query = "SELECT departments.id, departments.name, COUNT(projects.departmentId) as totalProjects, SUM(projects.status=1) as completedProjects FROM projects RIGHT JOIN departments ON departments.id=departmentId GROUP BY departments.id
            ORDER BY totalProjects DESC";

        $stmt= $this->conn->prepare($query);

        $stmt->execute();
        return $stmt;
    }
}