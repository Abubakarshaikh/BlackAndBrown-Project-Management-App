<?php

class User {
    private $table = "users";
    private $conn;
    
    public $id;

    public $name;

    
}