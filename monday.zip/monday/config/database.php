<?php



class Database
{
    private $host = "localhost";
    private $username = "bbitsolc_monday";
    private $dbname = "bbitsolc_monday";
    private $password = "8Ojk0Wgi=R.t";
    private $conn;

    public function connect()
    {
        $this->conn = null;
        try {
            $this->conn =
                new PDO(
                    'mysql:host=' . $this->host . ';dbname=' . $this->dbname,
                    $this->username,
                    $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo "CONNECTION ERROR" . $e->getMessage();
        }
     
        return $this->conn;
    }
}