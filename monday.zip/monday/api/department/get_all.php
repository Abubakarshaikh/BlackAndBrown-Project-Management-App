<?php
// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

include_once '../../models/department.php';
include_once '../../config/database.php';

$database = new Database();
$db = $database->connect();

$department= new Department($db);

$result = $department->getAll();
$num = $result->rowCount();

if($num > 0) {
    $departments_arr = array();

    while($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);

        $department_item = array(
            'name' => $name,
            'totalProjects'=>(int)$totalProjects,
            'id' => (int)$id,
            'completedProjects' =>(int) $completedProjects,
        );

        array_push($departments_arr, $department_item);
    }

    echo json_encode($departments_arr);

} else {
    // No Posts
    echo json_encode(
        array('message' => 'No Departments Found')
    );
}
