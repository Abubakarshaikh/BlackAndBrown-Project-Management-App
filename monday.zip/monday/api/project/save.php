<?php
// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once '../../config/database.php';
include_once '../../models/project.php';


$database = new Database();
$conn = $database->connect();



$project = new Project($conn);



$data = json_decode(file_get_contents("php://input"));


$project->departmentId = $data->departmentId;
$project->name = $data->name;
$project->descriptions = $data->descriptions;
$project->status = $data->status;
$project->deadline = date("Y-m-d H:i:s", $data->deadline/ 1000);


if($project->save()) {
    echo json_encode(
        array('status' => true)
    );
} else {
    echo json_encode(
        array('status' => false)
    );
}
