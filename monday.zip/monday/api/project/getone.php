<?php
// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

include_once '../../config/Database.php';
include_once '../../models/project.php';

// Instantiate DB & connect
$database = new Database();
$db = $database->connect();

// Instantiate blog post object
echo "getone";
$project = new Project($db);

// Get ID
$project->id = isset($_GET['id']) ? $_GET['id'] : die();

// Get post
echo "getone";
$project->getById();

// // Create array
// $project_arr = array(
//     'id' => $project->id,
//     'user_id' => $project->user_id,
//     'department_id' => $project->department_id,
//     'name' => $project->name,
//     'descriptions' => $project->descriptions,
//     'created_at' => $project->created_at
// );

// // Make JSON
// print_r(json_encode($project_arr));