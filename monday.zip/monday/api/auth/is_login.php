<?php

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');


include_once '../../models/auth.php';
include_once '../../config/database.php';

$database = new Database();
$conn = $database->connect();

$auth = new Auth($conn);

$data = json_decode(file_get_contents("php://input"));

$auth->token = $data->token;


$result = $auth->isLogin();
// Get row count
$num = $result->rowCount();

// Check if any posts
if($num > 0) {
    // Post array
    $projects_arr = array();
    // $posts_arr['data'] = array();

    while($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);

        $project_item = array(
            'id'=>(int)$id,
            'departmentId'=>(int)$departmentId,
            'name' =>$name,
            'email' => $email,
            
        );

        // Push to "data"
        array_push($projects_arr, $project_item);
        // array_push($posts_arr['data'], $post_item);
    }

    // Turn to JSON & output
    echo json_encode($project_item);

} else {
    // No Posts
    echo json_encode(
        array('message' => 'No Posts Found')
    );
}


