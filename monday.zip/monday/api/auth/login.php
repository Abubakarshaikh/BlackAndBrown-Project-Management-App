<?php

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');


include_once '../../models/auth.php';
include_once '../../config/database.php';

$database = new Database();
$conn = $database->connect();

$auth = new Auth($conn);

$data = json_decode(file_get_contents("php://input"));

$auth->email = $data->email;
$auth->password = $data->password;
$auth->token = $data->token;


if( $auth->loginByEmailAndPassword()){
    echo json_encode(
        array('message' => 'successfully')
    );
}
 else {
    // No Posts
    echo json_encode(
        array('message' => 'No Posts Found')
    );
}


