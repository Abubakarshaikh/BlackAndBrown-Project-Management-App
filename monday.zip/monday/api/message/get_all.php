<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
include_once '../../config/database.php';
include_once '../../models/message.php';

$database = new Database();
$db = $database->connect();
$message = new Message($db);

$message->projectId = isset($_GET['id']) ? $_GET['id'] : die();

$result = $message->getAllByProjectId();
$num = $result->rowCount();

if($num > 0) {
    $messages_arr = array();

    while($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);

        $message_item = array(
            'projectId'=>(int)$projectId,
            'message'=>$message,
            'senderId'=>(int)$senderId,
            'createdAt'=> strtotime($createdAt)
        );

        array_push($messages_arr, $message_item);
    }

    echo json_encode($messages_arr);

} else {
    echo json_encode(
        array('')
    );
}
