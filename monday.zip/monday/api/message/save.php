<?php
// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');


include_once '../../models/message.php';
include_once '../../config/database.php';

$database = new Database();
$conn = $database->connect();

$message = new Message($conn);

$data = json_decode(file_get_contents("php://input"));

$message->projectId = $data->projectId;
$message->message = $data->message;
$message->senderId = $data->senderId;




if($message->save()) {
    echo json_encode(
        array('status' => true)
    );
} else {
    echo json_encode(
        array('status' => false)
    );
}


